package com.bbs.common.dao;

public class BaseDao {

}

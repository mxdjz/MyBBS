package com.bbs.common.constant;

/**
 * 系统常量
 * @author qy199
 *
 */
public final class SystemConstant {
    
    /**
     * 板块缩略图路径
     */
    public final static String PLATE_IMAGE_FOLDER = "/bbs_image/plate_image/";
}

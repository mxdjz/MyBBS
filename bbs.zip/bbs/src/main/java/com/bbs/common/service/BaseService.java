package com.bbs.common.service;

public class BaseService {

}

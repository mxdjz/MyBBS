package com.bbs.common.controller;

public class BaseController {

}

package com.bbs.common.dao;

public interface IBaseDao {

    public Object findObjectById(String id);
    
}
